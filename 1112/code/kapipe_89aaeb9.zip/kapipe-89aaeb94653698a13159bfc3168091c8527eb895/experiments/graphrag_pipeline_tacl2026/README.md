# graphrag_pipeline_tacl2026

This directory contains example experiments for the GraphRAG pipeline (`kapipe.pipelines.GraphRAGPipeline`).

This experiment directory also provides the codebase used in the following paper:

- [Nishida et al., TACL 2026, Dissecting GraphRAG: A Modular Analysis of Knowledge Structuring for Factoid Question Answering.](https://aclanthology.org/2026.tacl-1.29/)

## Step 1. Installation

Install KAPipe by following the `README.md` in the repository root.

If you use a pyenv environment, you can install the dependencies as follows.

```bash
# 1. Create your own Python environment
pyenv install 3.11.14
pyenv virtualenv 3.11.14 <your-favorite-env-name>

# 2. Activate the Python environment in this directory
cd experiments/graphrag_pipeline_tacl2026
pyenv local <your-favorite-env-name>

# 3. Install the KAPipe library
python -m pip install -U kapipe
# or
python -m pip install -e ../..

# 4. Install dependencies specific to this directory
python -m pip install -r requirements.txt
```

## Step 2. Dataset Preparation

### Example dataset

This directory already includes example data.

```bash
experiments/graphrag_pipeline_tacl2026/data/examples/docre/documents.json
experiments/graphrag_pipeline_tacl2026/data/examples/docre/documents_with_triples.json
experiments/graphrag_pipeline_tacl2026/data/examples/kb/entity_dict.json
experiments/graphrag_pipeline_tacl2026/data/examples/qa/questions.json
experiments/graphrag_pipeline_tacl2026/data/examples/qa/questions_with_answers.json
```

### CDR-QA and Linked-DocRED-QA datasets

We provide the CDR-QA and Linked-DocRED-QA datasets used in the above paper in the following directories.

```bash
experiments/graphrag_pipeline_tacl2026/data/cdr_qa/qa/neighborhood_questions.json
experiments/graphrag_pipeline_tacl2026/data/cdr_qa/qa/intersection_questions.json
experiments/graphrag_pipeline_tacl2026/data/cdr_qa/qa/multihop_questions.json

experiments/graphrag_pipeline_tacl2026/data/linked_docred_qa/qa/neighborhood_questions.json
experiments/graphrag_pipeline_tacl2026/data/linked_docred_qa/qa/intersection_questions.json
experiments/graphrag_pipeline_tacl2026/data/linked_docred_qa/qa/multihop_questions.json
```

The original CDR and Linked-DocRED datasets, as well as the corresponding KBs (MeSH and DBPedia), can be prepared using the scripts in `experiments/datasets/`.

## Step 3. Configuration Setup

Adjust the settings in the following configuration file (HOCON format).

```bash
experiments/graphrag_pipeline_tacl2026/config/default.conf
```

## Step 4. Experiment Running

First, check `STORAGE_DATA` and `STORAGE_RESULTS` in the execution script and adjust them to your environment.

If you modified the configuration file or added new configuration entries, make sure that the execution script refers to the intended configuration.

Run each action sequentially using the following commands:

```bash
bash ./run_graphrag_pipeline.sh --actiontype ner
bash ./run_graphrag_pipeline.sh --actiontype ed_retrieval
bash ./run_graphrag_pipeline.sh --actiontype ed_reranking
bash ./run_graphrag_pipeline.sh --actiontype docre
bash ./run_graphrag_pipeline.sh --actiontype entity_graph_construction
bash ./run_graphrag_pipeline.sh --actiontype community_clustering
bash ./run_graphrag_pipeline.sh --actiontype report_generation
bash ./run_graphrag_pipeline.sh --actiontype chunking
bash ./run_graphrag_pipeline.sh --actiontype passage_retrieval_indexing
bash ./run_graphrag_pipeline.sh --actiontype inference
```

Run all actions at once:

```bash
bash ./run_graphrag_pipeline.sh --actiontype all
```

If you use the OpenAI API, set your API key in advance.

You can use the OpenAI Batch API for the following actions: `ner`, `ed_reranking`, `docre`, `inference`.

```bash
bash ./run_graphrag_pipeline.sh --actiontype ner --batch_mode submit
bash ./run_graphrag_pipeline.sh --actiontype ner --batch_mode fetch
bash ./run_graphrag_pipeline.sh --actiontype ed_retrieval
bash ./run_graphrag_pipeline.sh --actiontype ed_reranking --batch_mode submit
bash ./run_graphrag_pipeline.sh --actiontype ed_reranking --batch_mode fetch
bash ./run_graphrag_pipeline.sh --actiontype docre --batch_mode submit
bash ./run_graphrag_pipeline.sh --actiontype docre --batch_mode fetch
bash ./run_graphrag_pipeline.sh --actiontype entity_graph_construction
bash ./run_graphrag_pipeline.sh --actiontype community_clustering
bash ./run_graphrag_pipeline.sh --actiontype report_generation
bash ./run_graphrag_pipeline.sh --actiontype chunking
bash ./run_graphrag_pipeline.sh --actiontype passage_retrieval_indexing
bash ./run_graphrag_pipeline.sh --actiontype inference --batch_mode submit
bash ./run_graphrag_pipeline.sh --actiontype inference --batch_mode fetch
```
