from __future__ import annotations

from collections import OrderedDict
import datetime
from importlib.resources import files, as_file
import json
import logging
import os
import requests
import time
from typing import Any, Callable
import zipfile

import numpy as np
import pyhocon
from pyhocon.converter import HOCONConverter
from pyhocon import ConfigTree

from .datatypes import Document, Mention, Entity, Passage


logger = logging.getLogger(__name__)


########
# Utilities for reading/writing files
########


def read_lines(path: str, encoding: str = "utf-8") -> list[str]:
    """Read stripped lines from a text file."""

    with open(path, encoding=encoding) as f:
        lines = [line.strip() for line in f]

    return lines


def read_json(path: str, encoding: str | None = None) -> dict[str, Any] | list[dict[str, Any]]:
    """Read a JSON file."""

    with open(path, encoding=encoding) as f:
        obj = json.load(f)

    return obj


def write_json(path: str, obj: Any, ensure_ascii: bool = True) -> None:
    """Write a JSON-compatible object."""

    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=ensure_ascii, indent=4)


def read_jsonl(path: str, encoding: str | None = None) -> list[dict[str, Any]]:
    """Read a JSONL file."""

    records = []

    with open(path, "r", encoding=encoding) as f:
        for line in f:
            record = json.loads(line.strip())
            records.append(record)

    return records


def write_jsonl(
    path: str,
    records: list[dict[str, Any]],
    ensure_ascii: bool = True
) -> None:
    """Write a JSONL file."""

    with open(path, "w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=ensure_ascii) + "\n")


def read_vocab(path: str) -> dict[str, int]:
    """Read a tab-separated vocabulary file."""
    
    vocab: dict[str, int] = OrderedDict()
    with open(path) as f:
        for line in f:
            items = line.strip().split("\t")
            if len(items) == 2:
                word, word_id = items
            elif len(items) == 3:
                word, word_id, freq = items
            else:
                raise Exception("Invalid line: %s" % items)
            vocab[word] = int(word_id)

    return vocab


def write_vocab(
    path: str,
    data: list[tuple[str, int]] | list[str],
    write_frequency: bool = True,
) -> None:
    """Write a tab-separated vocabulary file."""

    with open(path, "w") as f:
        if write_frequency:
            for word_id, (word, freq) in enumerate(data):
                f.write("%s\t%d\t%d\n" % (word, word_id, freq))
        else:
            for word_id, word in enumerate(data):
                f.write("%s\t%d\n" % (word, word_id))


def get_hocon_config(
    config_path: str,
    config_name: str | None = None,
) -> ConfigTree:
    """Read a HOCON configuration."""

    config = pyhocon.ConfigFactory.parse_file(config_path)
    if config_name is not None:
        config = config[config_name]
    config.config_path = config_path
    config.config_name = config_name
    return config


def mkdir(path: str, newdir: str | None = None) -> None:
    """Create a directory when it does not exist."""

    if newdir is None:
        target = path
    else:
        target = os.path.join(path, newdir)
    if not os.path.exists(target):
        os.makedirs(target)
        logger.info("Created a new directory: %s" % target)


def print_list(
    lst: list[Any],
    with_index: bool = False,
    process: Callable[[Any], Any] | None = None,
) -> None:
    """Log list items."""

    for i, x in enumerate(lst):
        if process is not None:
            x = process(x)
        if with_index:
            logger.info(f"{i}: {x}")
        else:
            logger.info(x)


def safe_json_loads(
    generated_text: str,
    fallback: Any = None,
    list_type: bool = False,
) -> Any:
    """Parse a JSON object or list from generated text."""

    if list_type:
        begin_index = generated_text.find("[")
        end_index = generated_text.rfind("]")
    else:
        begin_index = generated_text.find("{")
        end_index = generated_text.rfind("}")

    if begin_index < 0 or end_index < 0:
        logger.info(f"Failed to parse the generated text into a JSON object: '{generated_text}'")
        return fallback

    json_text = generated_text[begin_index: end_index + 1]

    try:
        json_obj = json.loads(json_text)
    except Exception as e:
        logger.info(f"Failed to parse the generated text into a JSON object: '{json_text}'")
        logger.info(e)
        return fallback

    if list_type:
        if not isinstance(json_obj, list):
            logger.info(f"The parsed JSON object is not a list: '{json_obj}'")
            return fallback
    else:
        if not isinstance(json_obj, dict):
            logger.info(f"The parsed JSON object is not a dictionary: '{json_obj}'")
            return fallback

    return json_obj


# def download_folder_if_needed(dest: str, url: str, chunk_size: int = 8192) -> None:
#     # Skip, if destination (folter) exists and is non-empty
#     if os.path.exists(dest) and os.path.isdir(dest) and os.listdir(dest):
#         return

#     # Prepare download location
#     parent_dir = os.path.dirname(dest)
#     mkdir(parent_dir)

#     # Define zip path as "<parent_dir>/<basename(dest)>.zip"
#     zip_filename = os.path.basename(dest) + ".zip"
#     zip_path = os.path.join(parent_dir, zip_filename)

#     try:
#         # Download the zip
#         with requests.get(url, stream=True, timeout=10) as response:
#             response.raise_for_status()  # Raise an error for bad status codes

#             total_size = int(response.headers.get("content-length", 0))
#             progress_bar = tqdm(
#                 total=total_size,
#                 unit='B',
#                 unit_scale=True,
#                 desc=f"Downloading {os.path.basename(zip_filename)}"
#             )

#             with open(zip_path, "wb") as f:
#                 for chunk in response.iter_content(chunk_size=chunk_size):
#                     if chunk:
#                         f.write(chunk)
#                         progress_bar.update(len(chunk))

#             progress_bar.close()

#         # Extract zip to dest
#         with zipfile.ZipFile(zip_path, "r") as zip_ref:
#             zip_ref.extractall(dest)

#     except Exception as e:
#         # Clean up on failure
#         if os.path.exists(zip_path):
#             os.remove(zip_path)
#         raise RuntimeError(f"Failed to download or extract {url} → {dest}: {e}")

#     finally:
#         # Clean up zip file
#         if os.path.exists(zip_path):
#             os.remove(zip_path)


########
# Utilities for data processing
########


def flatten_lists(list_of_lists: list[list[Any]]) -> list[Any]:
    """Flatten one level of nested lists."""

    return [elem for lst in list_of_lists for elem in lst]


def pretty_format_dict(dct: dict[str, Any]) -> str:
    """Format a dictionary as pretty JSON text."""

    return "{}".format(json.dumps(dct, indent=4))


########
# Utilities for measuring elapsed time
########


def get_current_time() -> str:
    """Return the current timestamp."""

    return datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")


class StopWatch(object):
    """A class to measure elapsed time for named spans."""

    def __init__(self):
        self.dictionary: dict[str | None, dict[str, float]] = {}

    def start(self, name: str | None = None) -> None:
        start_time = time.time()
        self.dictionary[name] = {}
        self.dictionary[name]["start"] = start_time

    def stop(self, name: str | None = None) -> None:
        stop_time = time.time()
        self.dictionary[name]["stop"] = stop_time

    def get_time(self, name: str | None = None, minute: bool = False) -> float:
        start_time = self.dictionary[name]["start"]
        stop_time = self.dictionary[name]["stop"]
        span = stop_time - start_time
        if minute:
            span /= 60.0
        return span


########
# Utilities for tracking the best score
########


class BestScoreHolder(object):
    """A class to track the best score during training."""


    def __init__(self, scale: float = 1.0, higher_is_better: bool = True):
        self.scale = scale
        self.higher_is_better = higher_is_better

        # Select the comparison function
        if higher_is_better:
            self.comparison_function: Callable[[float, float], bool] = (
                lambda best, cur: best < cur
            )
        else:
            self.comparison_function: Callable[[float, float], bool] = (
                lambda best, cur: best > cur
            )

        # Initialize the tracked values
        self.init()

    def init(self) -> None:
        """Initialize the tracked values."""

        if self.higher_is_better:
            self.best_score = -np.inf
        else:
            self.best_score = np.inf
        self.best_step = 0
        self.patience = 0

    def compare_scores(self, score: float, step: int) -> bool:
        """Compare the current score with the best score and update if necessary."""

        # Check whether the current score improves the best score
        if self.comparison_function(self.best_score, score):
            # Log the score update
            logger.info(
                "(best_score = %.02f, best_step = %d, patience = %d) -> "
                "(%.02f, %d, %d)"
                % (
                    self.best_score * self.scale,
                    self.best_step,
                    self.patience,
                    score * self.scale,
                    step,
                    0,
                )
            )

            # Update the best score, step, and patience 
            self.best_score = score
            self.best_step = step
            self.patience = 0

            # Report the the score improved
            return True
        else:
            # Log the patience update
            logger.info(
                "(best_score = %.02f, best_step = %d, patience = %d) -> "
                "(%.02f, %d, %d)"
                % (
                    self.best_score * self.scale,
                    self.best_step,
                    self.patience,
                    self.best_score * self.scale,
                    self.best_step,
                    self.patience + 1,
                )
            )

            # Update the patience 
            self.patience += 1

            # Report that the score did not improve
            return False

    def ask_finishing(self, max_patience: int) -> bool:
        """Check whether the training should be stopped based on patience."""
        return self.patience >= max_patience


########
# Utilities for specific components (tasks)
########


def aggregate_mentions_to_entities(
    document: Document,
    mentions: list[Mention]
) -> list[Entity]:
    """Aggregate linked mentions into entities."""

    # Initialize per-entity aggregation storage
    entity_id_to_info: dict[str, dict[str, Any]] = {}

    # Aggregate mention information by predicted entity ID
    for m_i in range(len(document["mentions"])):
        # Read the gold mention name and type
        name = document["mentions"][m_i]["name"]
        entity_type = document["mentions"][m_i]["entity_type"]

        # Read the predicted entity ID
        entity_id = mentions[m_i]["entity_id"]

        # Append mention information to an existing entity,
        # or create a new entity if the entity ID is not seen before
        if entity_id in entity_id_to_info:
            entity_id_to_info[entity_id]["mention_indices"].append(m_i)
            entity_id_to_info[entity_id]["mention_names"].append(name)
            # TODO
            # Confliction of entity types can appear, if EL model does not care about it.
            # assert (
            #     entity_id_to_info[entity_id]["entity_type"]
            #     == entity_type
            # )
        else:
            entity_id_to_info[entity_id] = {}
            entity_id_to_info[entity_id]["mention_indices"] = [m_i]
            entity_id_to_info[entity_id]["mention_names"] = [name]
            entity_id_to_info[entity_id]["entity_type"] = entity_type

    # Initialize the output entities
    entities: list[Entity] = []

    # Convert the aggregation storage into entity records
    for entity_id in entity_id_to_info.keys():
        # Read the aggregated mention indices, names, and entity type for the current entity ID
        mention_indices = entity_id_to_info[entity_id]["mention_indices"]
        mention_names = entity_id_to_info[entity_id]["mention_names"]
        entity_type = entity_id_to_info[entity_id]["entity_type"]

        # Append the entity record
        entities.append({
            "mention_indices": mention_indices,
            "mention_names": mention_names,
            "entity_type": entity_type,
            "entity_id": entity_id,
        })

    return entities


def create_text_from_passage(passage: Passage, sep: str) -> str:
    """Create display text string from a passage."""

    # Use only the body text when the passage has no title
    if "title" not in passage:
        text = passage["text"]
    
    # Use only the title when the body text is empty
    elif passage["text"].strip() == "":
        text = passage["title"]

    # Otherwise, join the title and body text with the given separator
    else:
        text = passage["title"] + sep + passage["text"]

    return text


def read_prompt_template(
    prompt_template_name_or_path: str,
    prompt_template_package_name: str,
) -> str:
    """Read a prompt template from a package or a file path."""

    # List text files in prompt-template package
    prompt_template_names = [
        x.name for x in files(prompt_template_package_name).iterdir()
        if x.name.endswith(".txt") and x.is_file() and not x.name.startswith("_")
    ]

    # Build the filename for a packaged prompt template
    candidate_filename = prompt_template_name_or_path + ".txt"

    # Load the packaged prompt template when the given name exists
    if candidate_filename in prompt_template_names:
        template_path = files(prompt_template_package_name).joinpath(candidate_filename)

        # Convert the package resource into a readable file-system path
        with as_file(template_path) as path:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()

    # Validate that the prompt template file path exists
    assert os.path.isfile(prompt_template_name_or_path)

    # Load the prompt template from the explicit file path
    with open(prompt_template_name_or_path, "r", encoding="utf-8") as f:
        return f.read()


def create_intra_inter_map(document) -> dict[str, str]:
    """Create intra/inter labels for entity pairs."""

    # Initialize the output map
    intra_inter_map: dict[str, str] = {}

    # Initialize token-index to sentence-index mapping
    token_index_to_sent_index: list[int] = []

    # Assign each token index to its corresponding sentence index
    for sent_i, sent in enumerate(document["sentences"]):
        sent_words = sent.split()
        token_index_to_sent_index.extend(
            [sent_i for _ in range(len(sent_words))]
        )

    # Initialize mention-index to sentence-index mapping
    mention_index_to_sentence_index: list[int] = []

    # Assign each mention to its sentence
    for mention in document["mentions"]:
        begin_token_index, end_token_index = mention["span"]
        sentence_index = token_index_to_sent_index[begin_token_index]

        # Validate that the mention stays inside the same sentence
        assert token_index_to_sent_index[end_token_index] == sentence_index

        mention_index_to_sentence_index.append(sentence_index)

    entities = document["entities"]

    # Label each unordered entity pair
    for u_entity_i in range(len(entities)):
        # Read the first entity
        u_entity = entities[u_entity_i]
        u_mention_indices = u_entity["mention_indices"]
        u_sent_indices = [
            mention_index_to_sentence_index[i] for i in u_mention_indices
        ]
        u_sent_indices = set(u_sent_indices)

        for v_entity_i in range(u_entity_i, len(entities)):
            # Read the second entity
            v_entity = entities[v_entity_i]
            v_mention_indices = v_entity["mention_indices"]
            v_sent_indices = [
                mention_index_to_sentence_index[i] for i in v_mention_indices
            ]
            v_sent_indices = set(v_sent_indices)

            # Mark the pair as inter-sentence when no sentence is shared
            if len(u_sent_indices & v_sent_indices) == 0:
                intra_inter_map[f"{u_entity_i}-{v_entity_i}"] = "inter"
                intra_inter_map[f"{v_entity_i}-{u_entity_i}"] = "inter"

            # Mark the pair as intra-sentence when at least one sentence is shared
            else:
                intra_inter_map[f"{u_entity_i}-{v_entity_i}"] = "intra"
                intra_inter_map[f"{v_entity_i}-{u_entity_i}"] = "intra"

    return intra_inter_map


def create_seen_unseen_map(
    document,
    seen_pairs: set[tuple[str, str]]
) -> dict[str, str]:
    """Create seen/unseen labels for entity pairs."""

    # Initialize the output map
    seen_unseen_map: dict[str, str] = {}

    entities = document["entities"]

    # Label each unordered entity pair
    for u_entity_i in range(len(entities)):
        # Read the first entity
        u_entity = entities[u_entity_i]
        u_entity_id = u_entity["entity_id"]

        for v_entity_i in range(u_entity_i, len(entities)):
            # Read the second entity
            v_entity = entities[v_entity_i]
            v_entity_id = v_entity["entity_id"]

            # Mark the pair as seen when either direction exists
            if (
                ((u_entity_id, v_entity_id) in seen_pairs)
                or
                ((v_entity_id, u_entity_id) in seen_pairs)
            ):
                seen_unseen_map[f"{u_entity_id}-{v_entity_id}"] = "seen"
                seen_unseen_map[f"{v_entity_id}-{u_entity_id}"] = "seen"

            # Mark the pair as unseen otherwise
            else:
                seen_unseen_map[f"{u_entity_id}-{v_entity_id}"] = "unseen"
                seen_unseen_map[f"{v_entity_id}-{u_entity_id}"] = "unseen"

    return seen_unseen_map

