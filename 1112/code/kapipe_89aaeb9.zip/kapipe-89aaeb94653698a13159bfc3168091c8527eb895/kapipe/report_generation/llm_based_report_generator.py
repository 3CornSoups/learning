from __future__ import annotations

import logging

import networkx as nx
import torch

from .. import utils
from ..datatypes import (
    CommunityRecord,
    Passage
)
from ..llms import HuggingFaceLLM, OpenAILLM
from .base import BaseReportGenerator


logger = logging.getLogger(__name__)


class LLMBasedReportGenerator(BaseReportGenerator):
    
    def __init__(
        self,
        model: HuggingFaceLLM | OpenAILLM,
        prompt_template_name_or_path: str = "report_generation_01_zeroshot",
        relation_map: dict[str, str] | None = None,
    ):
        self.model = model
        self.prompt_template_name_or_path = prompt_template_name_or_path

        # Load the prompt template for report generation
        self.prompt_template = utils.read_prompt_template(
            prompt_template_name_or_path=self.prompt_template_name_or_path,
            prompt_template_package_name="kapipe.report_generation.prompt_templates"
        )

        # Validate the prompt template
        if "{content_prompt}" not in self.prompt_template:
            raise ValueError(
                "The prompt template must contain {content_prompt}."
            )

        # relation_map is used to map relation names from the model's output 
        # to the desired format.
        if relation_map is None:
            relation_map = {}
        self.relation_map = relation_map

    def generate_community_reports(
        self,
        # Input
        graph: nx.MultiDiGraph,
        communities: list[CommunityRecord],
        node_attr_keys: tuple[str, ...],
        edge_attr_keys: tuple[str, ...],
        # Misc.
        parse_generated_text_fn = None,
    ) -> list[Passage]:
        """Generate reports for each community."""

        assert len(node_attr_keys) > 0
        assert len(edge_attr_keys) > 0

        # Set the default parsing function if none is provided
        if parse_generated_text_fn is None:
            parse_generated_text_fn = parse_generated_text

        # Save the context for later use
        self.graph = graph
        self.node_attr_keys = node_attr_keys
        self.edge_attr_keys = edge_attr_keys
        self.parse_generated_text_fn = parse_generated_text_fn
        self.n_total = len(communities) - 1 # Exclude ROOT
        self.count = 0

        # Convert list of communities to dictionary for quick access
        communities_dict = {c["community_key"]: c for c in communities}

        # Memorize the community order for later use
        community_order: dict[str, int] = {
            c["community_key"]: i for i, c in enumerate(communities)
        }

        # Generate community reports recursively in the bottom-up manner
        reports: list[Passage] = []
        self._recursive(
            community=communities_dict["ROOT"],
            communities_dict=communities_dict,
            reports=reports,
        )

        # Finally, sort the reports based on the community order
        reports.sort(key=lambda r: community_order[r["community_key"]])

        return reports


    def _recursive(
        self,
        community: CommunityRecord,
        communities_dict: dict[str, CommunityRecord],
        reports: list[Passage]
    ) -> Passage | None:
        """Recursively generate reports in bottom-up fashion."""

        # Generate the sub-communities' reports recursively
        child_reports: list[Passage] = []
        for child_community_key in community["child_community_keys"]:
            if child_community_key in communities_dict:
                child_community = communities_dict[child_community_key]
                child_report = self._recursive(
                    community=child_community,
                    communities_dict=communities_dict,
                    reports=reports
                )
                child_reports.append(child_report)

        # Skip ROOT
        if community["community_key"] == "ROOT":
            return None

        # Collect direct nodes (excluding those covered by child reports)
        nodes_of_children = utils.flatten_lists([c["nodes"] for c in child_reports])
        direct_nodes = [
            node for node in community["nodes"] if node not in nodes_of_children
        ]

        # Generate this community's report
        report = self.generate_community_report(
            community=community,
            direct_nodes=direct_nodes,
            child_reports=child_reports
        )

        # Record the generated report
        reports.append(report)

        return report           

    def generate_community_report(
        self,
        community: CommunityRecord,
        direct_nodes: list[str],
        child_reports: list[Passage]
    ) -> Passage:
        """Generate a report for one community."""

        self.count += 1

        # Show progress
        logger.info(f"[{self.count}/{self.n_total}] Generating a report for community (Key:{community['community_key']}) with {len(direct_nodes)} direct nodes and {len(child_reports)} sub communities (Keys:{[c['community_key'] for c in child_reports]})...")

        with torch.no_grad():
            # Switch to inference mode for Hugging Face models
            if self.model.provider == "hf":
                self.model.llm.eval()

            # Generate a prompt
            prompt = self.generate_prompt(
                direct_nodes=direct_nodes,
                child_reports=child_reports,
            )

            # Generate a plain-text report based on the prompt
            generated_text = self.model.generate(prompt)

            # Parse the generated report into its title and text
            processed_title, processed_text = self.parse_generated_text_fn(
                generated_text
            )

            return {
                "passage_key": f"{community['community_key']}/report",
                "title": processed_title,
                "text": processed_text,
            } | community

    def generate_prompt(
        self,
        direct_nodes: list[str],
        child_reports: list[Passage]
    ) -> str:
        """Generate an LLM prompt from community data."""

        # Limit number of direct nodes
        if len(direct_nodes) >= 100:
            logger.info(f"[{self.count}/{self.n_total}] Reducing nodes to top 100 primary nodes among {len(direct_nodes)} nodes")
            direct_nodes = [
                n for n, _ in sorted(
                    self.graph.subgraph(direct_nodes).degree(),
                    key=lambda x: x[1],
                    reverse=True
                )[:100]
            ]

        # Gather edges among the nodes
        edges = [
            (h,t,p) for h,t,p in self.graph.edges(direct_nodes, data=True)
            if (h in direct_nodes) and (t in direct_nodes)
        ]

        assert len(direct_nodes) + len(edges) + len(child_reports) > 0

        content_prompt = ""

        # Generate prompt part for nodes
        if len(direct_nodes) > 0:
            # content_prompt += "Entities:\n"
            content_prompt += "Nodes:\n"
            for node in direct_nodes:
                props = self.graph.nodes[node]

                # name = props["name"].replace("|", " ")
                # etype = props["entity_type"].replace("|", " ")
                # desc = props["description"].replace("|", " ").replace("\n", " ").rstrip()
                # if desc == "":
                #     desc = "N/A"
                # content_prompt += f"- {name} | {etype} | {desc}\n"

                # Create one line based on node_attr_keys
                values = []
                for key in self.node_attr_keys:
                    v = props[key].replace("|", " ").replace("\n", " ").strip()
                    if key == "description" and v == "":
                        v = "N/A"
                    values.append(v)
                line = " | ".join(values)
                content_prompt += f"- {line}\n"

            content_prompt += "\n"

        # Generate prompt part for edges
        if len(edges) > 0:
            content_prompt += "Relationships:\n"
            for head, tail, props in edges:
                # head_name = self.graph.nodes[head]["name"].replace("|", " ")
                # tail_name = self.graph.nodes[tail]["name"].replace("|", " ")
                # relation = props["relation"]
                # relation = self.relation_map.get(relation, relation).replace("|", " ")
                # content_prompt += f"- {head_name} | {relation} | {tail_name}\n"

                # Create one line based on edge_attr_keys
                head_name = self.graph.nodes[head][self.node_attr_keys[0]].replace("|", " ").replace("\n", " ").strip()
                tail_name = self.graph.nodes[tail][self.node_attr_keys[0]].replace("|", " ").replace("\n", " ").strip()
                relation = props[self.edge_attr_keys[0]]
                relation = self.relation_map.get(relation, relation).replace("|", " ").replace("\n", " ").strip()
                values = [head_name, relation, tail_name]
                if len(self.edge_attr_keys) > 1:
                    for key in self.edge_attr_keys[1:]:
                        v = props[key].replace("|", " ").replace("\n", " ").strip()
                        values.append(v)
                line = " | ".join(values)
                content_prompt += f"- {line}\n"

            content_prompt += "\n"

        # Generate prompt part for child reports
        if len(child_reports) > 0:
            content_prompt += "Sub-Communities' Reports:\n"
            content_prompt += "\n"
            for c_i, child_report in enumerate(child_reports):
                title = child_report["title"].strip()
                text = child_report["text"].strip()
                content_prompt += f"[Sub-Community {c_i+1}]\n"
                content_prompt += f"Title: {title}\n"
                content_prompt += f"{text}\n"
                if c_i < len(child_reports) - 1:
                    content_prompt += "\n"

        # Finalize the prompt
        prompt = self.prompt_template.format(content_prompt=content_prompt.strip())

        return prompt


def parse_generated_text(generated_text: str) -> tuple[str, str]:
    """Parse the LLM output into (title, summary text)."""

    json_obj = utils.safe_json_loads(generated_text=generated_text, fallback=None)
    if json_obj is None:
        return "No Title", generated_text

    try:
        title = json_obj["title"]
        text = json_obj["summary"] + "\n"
        for i, finding in enumerate(json_obj["findings"]):
            text += f"[Finding {i+1}] {finding['summary']}: {finding['explanation']}\n"
        text = text.rstrip()
        return title, text
    except Exception as e:
        logger.warning(f"Failed to parse structured JSON: {e}")
        return "No Title", generated_text
